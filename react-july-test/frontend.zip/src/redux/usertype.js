export const LOGIN ="LOGIN";
export const REGISTER ="REGISTER";
export const LOGOUT = "LOGOUT";
