export const ALLDATA = "ALLDATA";
export const FATCHING ="FATCHING ";
export const CURRENTPOST = "CURRENTPOST";
export const CREATEPOST = "CREATEPOST";
export const DELETEPOST = 'DELETEPOST';
export const UPDATEPOST = "UPDATEPOST";
export const USERPOST = "USERPOST";

